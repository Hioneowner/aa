package cn.itcast.day4

/**
  * Created by ZX on 2016/4/14.
  */
class Girl(val name: String, val faceValue: Int, val size: Int) {

}
