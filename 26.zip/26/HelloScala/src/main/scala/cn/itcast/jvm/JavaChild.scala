package cn.itcast.jvm

/**
  * Created by ZX on 2016/3/29.
  */
object JavaChild {

}
