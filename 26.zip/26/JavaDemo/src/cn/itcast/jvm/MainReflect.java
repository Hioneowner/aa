package cn.itcast.jvm;

import java.lang.reflect.Method;

public class MainReflect {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) throws Exception {
		Class clazz = Class.forName("cn.itcast.jvm.JChild");
		Method mainMethod = clazz.getMethod("main", String[].class);
		mainMethod.invoke(null, (Object) new String[] {"itcast"});
	}
}
