package cn.itcast.jvm;

public class JChild {

	public static void main(String[] args) throws Exception {
		System.out.println("123");
		Thread.sleep(20000);
	}

}
