package cn.itcast.jvm;


public class JVMTest {

	public static void main(String[] args) throws Exception {
		Process process = Runtime.getRuntime().exec("C:\\Program Files\\Java\\jdk1.7.0_45\\bin\\java -classpath C:\\workspace\\JavaDemo\\bin cn.itcast.jvm.JChild");
		process.waitFor();
		Thread.sleep(20000);
	}

}
