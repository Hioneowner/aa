package cn.itcast.genericity;

public class Pair<T extends Comparable<T>> {

	private T first;
	private T second;
	
	public Pair(T first, T second){
		this.first = first;
		this.second = second;
	}
	
	public T bigger(){
		return first.compareTo(second) > 0 ? first : second;
	}
	
	public static void main(String[] args) {
		Pair<Integer> p = new Pair<Integer>(1, 2);
		System.out.println(p.bigger());
		
	}
}


