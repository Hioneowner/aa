package cn.itcast.genericity;

import java.util.Arrays;
import java.util.List;


public class P {


	
	public <T extends People> void up(T t){
		System.out.println(t);
	}
	
	public static void main(String[] args) {
		//List<? extends People> list1 = Arrays.asList(new People(), new Korean());
		List<? super Korean> l2 = Arrays.asList(new Korean(), new People(), new Ape(), new Hatano());
		l2.get(0);
		l2.get(3);
		
		P p = new P();
		p.up(new People());
	}
}

class Ape{
	
}

class People extends Ape{
	
}

class Korean extends People{
	
}

class Japanese extends People{
	
}

class Hatano extends Japanese{
	  
}